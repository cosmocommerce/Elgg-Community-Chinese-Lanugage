<?php
	$english = array(
		'twitterservice' => 'Twitter Service',
		'twitterservice:postwire' => 'By setting the following option all messages you post to The Wire will be sent to your twitter account. Do you want to post your messages from The Wire to Twitter?',
		'twitterservice:twittername' => 'Twitter username',
		'twitterservice:twitterpass' => 'Twitter password',
	);
					
	add_translation("en",$english);
?>