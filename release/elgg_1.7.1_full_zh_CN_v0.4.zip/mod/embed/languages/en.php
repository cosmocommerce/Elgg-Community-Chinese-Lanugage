<?php

	$english = array(
	
		'media:insert' => 'Embed / upload media',
	
		'embed:instructions' => 'Click on any file to embed it into your content.',
	
		'embed:media' => 'Embed media',
		'upload:media' => 'Upload media',
	
		'embed:file:required' => 'No file upload facilities were found. The system administrator may need to upload the file plugin or similar.',
	
	);
					
	add_translation("en",$english);

?>