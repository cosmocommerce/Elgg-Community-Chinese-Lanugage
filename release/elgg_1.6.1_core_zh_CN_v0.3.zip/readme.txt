Chinese Community: elgg.org.cn
Support Company: cosmocommerce.com

Next Generation Web Creative Service Provider and Enterprise Solution Consultants

Installation:
Just copy the language file to your server's languages folder.
